# A fun little ripoff Netflix...but with buff anime characters. So NetFlex

## CSS Flex example for my students