import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import Forms from './components/Forms';

function App() {

  return (
    <div className="App">
      <h1>Todo List</h1>
      <Forms />
    </div>
  );
}

export default App;