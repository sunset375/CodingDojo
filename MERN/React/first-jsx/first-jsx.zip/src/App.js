import logo from './logo.svg';
import './App.css';
import Hello from './components/Hello.jsx'

function App() {
  return (
    <div>
      

      <Hello/>
    </div>
  );
}

export default App;
