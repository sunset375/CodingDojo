package ZooKeeperPt2;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat batbat = new Bat();
		
		batbat.attackTown();
		batbat.attackTown();
		batbat.attackTown();
		
		
		batbat.eatHumans();
		batbat.eatHumans();
		
		batbat.fly();
		
		
		batbat.displayEnergy();

		
	
	}

}
