package ZooKeeperPt1;

public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla g1 = new Gorilla();
		
		g1.throwSomething();
		g1.throwSomething();
		g1.throwSomething();
		
		
		g1.eatBanana();
		g1.eatBanana();

		
		g1.climb();
		
		g1.displayEnergy();
		
	}

}
