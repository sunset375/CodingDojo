package com.kim.controllersAndView;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllersAndViewApplicationTests {

	@Test
	void contextLoads() {
	}

}
