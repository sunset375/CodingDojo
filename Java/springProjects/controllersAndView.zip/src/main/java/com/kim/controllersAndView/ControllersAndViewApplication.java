package com.kim.controllersAndView;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllersAndViewApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControllersAndViewApplication.class, args);
	}

}
