package com.kim.beltExam.repositories;

import org.springframework.data.repository.CrudRepository;

import com.kim.beltExam.models.Idea;

public interface IdeaRepository extends CrudRepository<Idea, Long>{

}
