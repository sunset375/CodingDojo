package com.kim.beltExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeltExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
