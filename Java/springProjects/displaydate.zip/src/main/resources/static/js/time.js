function checkTimePage(){
    alert("This is the time template")
}

console.log("Testing")