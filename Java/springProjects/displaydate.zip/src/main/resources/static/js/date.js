function checkDatePage(){
    alert("This is the date template")
}

console.log("Testing")